import React from 'react'
import Layout from '../../HOCs/Layout'

export default function Home() {
    return (
        <Layout>
            
        </Layout>
    )
}
