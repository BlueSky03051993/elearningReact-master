import { makeStyles } from "@material-ui/core/styles";

export const useStyles = makeStyles((theme) => ({
    MuiContainerRoot: {
        padding : '0px !important',
    },
    imgLogo:{
        width: 110,
        padding: 10,
        margin: 10,
    }
}))