export const TOKEN_KEY = '$2y$12$mowehgP4wf8lBA4/i3wIK.Ewgh7nVxTBESiEXrcb1CxXixVVQNwtm';
export const SET_TOKEN = 'SET_TOKEN';